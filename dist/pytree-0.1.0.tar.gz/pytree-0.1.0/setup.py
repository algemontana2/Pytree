from setuptools import setup, find_packages

setup(
    name='pytree',
    version='0.1.0',
    description='A simple GEDCOM parser library in Python',
    author='King Al',
    author_email='aleich989@gmail.com',
    packages=find_packages(),
    install_requires=[],
)
